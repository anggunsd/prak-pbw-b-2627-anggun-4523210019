<?php

function statusKelulusan(float $ipk): string
{
    if ($ipk >= 3.50) return 'Sangat Memuaskan';
    if ($ipk >= 3.00) return 'Memuaskan';
    return 'Perlu Peningkatan';
}

$mahasiswa = [
    'nim' => '4523019',
    'nama' => 'Anggun',
    'prodi' => 'Teknik Informatika',
    'semester' => 3,
    'ipk' => 3.80
];

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Biodata Mahasiswa</title>
</head>
<body>

<h1>Biodata Mahasiswa</h1>

<ul>
    <?php foreach ($mahasiswa as $kunci => $nilai): ?>
        <li>
            <?= ucfirst($kunci) ?> :
            <?= htmlspecialchars((string)$nilai) ?>
        </li>
    <?php endforeach; ?>
</ul>

<p>
    Predikat:
    <?= statusKelulusan($mahasiswa['ipk']) ?>
</p>

</body>
</html>