
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Produk</title>
    <style>
        body { font-family: Arial; margin: 35px; background: #f3f4f6; }
        form { max-width: 500px; margin: auto; padding: 25px;
            background: white; border-radius: 10px; }
        input { width: 100%; padding: 10px; margin: 8px 0 16px;
            box-sizing: border-box; }
        button, a { padding: 10px 15px; text-decoration: none; }
        button { background: #16a34a; color: white; border: 0; }
    </style>
</head>
<body>
<form method="POST" action="index.php?aksi=store">
    <h2>Tambah Produk</h2>

    <label>Nama Produk</label>
    <input type="text" name="nama_produk" maxlength="100" required>

    <label>Harga (Rp)</label>
    <input type="number" name="harga" min="0" step="0.01" required>

    <label>Stok</label>
    <input type="number" name="stok" min="0" step="1" required>

    <button type="submit">Simpan Produk</button>
    <a href="index.php">Kembali</a>
</form>
</body>
</html>
