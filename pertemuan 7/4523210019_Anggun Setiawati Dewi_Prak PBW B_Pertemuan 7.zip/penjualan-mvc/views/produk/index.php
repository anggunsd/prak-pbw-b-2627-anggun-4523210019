
<?php
function aman($nilai) {
    return htmlspecialchars((string)$nilai, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar Produk</title>
    <style>
        body { font-family: Arial; margin: 35px; background: #f3f4f6; }
        .container { max-width: 900px; margin: auto; background: white;
            padding: 25px; border-radius: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #1d4ed8; color: white; }
        a, button { display: inline-block; padding: 9px 13px;
            text-decoration: none; border-radius: 5px; }
        .tambah { background: #16a34a; color: white; }
        .edit { background: #2563eb; color: white; }
        .pesan { color: #15803d; }
    </style>
</head>
<body>
<div class="container">
    <h1>Daftar Produk</h1>

    <?php if (($_GET['pesan'] ?? '') === 'tambah'): ?>
        <p class="pesan">Produk berhasil ditambahkan.</p>
    <?php elseif (($_GET['pesan'] ?? '') === 'update'): ?>
        <p class="pesan">Produk berhasil diperbarui.</p>
    <?php endif; ?>

    <a class="tambah" href="index.php?aksi=create">+ Tambah Produk</a>

    <table>
        <thead>
        <tr>
            <th>No.</th>
            <th>Nama Produk</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
        <?php $no = 1; ?>
        <?php while ($row = mysqli_fetch_assoc($produk)): ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= aman($row['nama_produk']) ?></td>
                <td>Rp <?= number_format((float)$row['harga'], 0, ',', '.') ?></td>
                <td><?= (int)$row['stok'] ?></td>
                <td>
                    <a class="edit"
                       href="index.php?aksi=edit&id=<?= (int)$row['id'] ?>">
                        Edit
                    </a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>
</body>
</html>
