
<?php
function amanEdit($nilai) {
    return htmlspecialchars((string)$nilai, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Produk</title>
    <style>
        body { font-family: Arial; margin: 35px; background: #f3f4f6; }
        form { max-width: 500px; margin: auto; padding: 25px;
            background: white; border-radius: 10px; }
        input { width: 100%; padding: 10px; margin: 8px 0 16px;
            box-sizing: border-box; }
        button, a { padding: 10px 15px; text-decoration: none; }
        button { background: #2563eb; color: white; border: 0; }
    </style>
</head>
<body>
<form method="POST" action="index.php?aksi=update">
    <h2>Edit Produk</h2>

    <input type="hidden" name="id" value="<?= (int)$produk['id'] ?>">

    <label>Nama Produk</label>
    <input type="text" name="nama_produk"
           value="<?= amanEdit($produk['nama_produk']) ?>"
           maxlength="100" required>

    <label>Harga (Rp)</label>
    <input type="number" name="harga"
           value="<?= amanEdit($produk['harga']) ?>"
           min="0" step="0.01" required>

    <label>Stok</label>
    <input type="number" name="stok"
           value="<?= (int)$produk['stok'] ?>"
           min="0" step="1" required>

    <button type="submit">Simpan Perubahan</button>
    <a href="index.php">Kembali</a>
</form>
</body>
</html>
