<?php
class ProdukModel {
    private $db;

    public function __construct($koneksi) {
        $this->db = $koneksi;
    }

    public function getAllProduk() {
        return mysqli_query($this->db, "SELECT * FROM produk ORDER BY id DESC");
    }

    public function getProdukById($id) {
        $stmt = mysqli_prepare($this->db, "SELECT * FROM produk WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $produk = mysqli_fetch_assoc($result);
        mysqli_stmt_close($stmt);
        return $produk;
    }

    public function tambahProduk($nama, $harga, $stok) {
        $stmt = mysqli_prepare(
            $this->db,
            "INSERT INTO produk (nama_produk, harga, stok) VALUES (?, ?, ?)"
        );
        mysqli_stmt_bind_param($stmt, "sdi", $nama, $harga, $stok);
        $berhasil = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $berhasil;
    }

    public function updateProduk($id, $nama, $harga, $stok) {
        $stmt = mysqli_prepare(
            $this->db,
            "UPDATE produk SET nama_produk = ?, harga = ?, stok = ? WHERE id = ?"
        );
        mysqli_stmt_bind_param($stmt, "sdii", $nama, $harga, $stok, $id);
        $berhasil = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $berhasil;
    }
}
?>