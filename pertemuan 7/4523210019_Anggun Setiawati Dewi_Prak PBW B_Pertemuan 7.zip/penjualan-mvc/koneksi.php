<?php
$host = "localhost";
$user = "root";
$password = "";
$dbname = "penjualan_mvc";

$koneksi = mysqli_connect($host, $user, $password, $dbname);
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
mysqli_set_charset($koneksi, "utf8mb4");
?>