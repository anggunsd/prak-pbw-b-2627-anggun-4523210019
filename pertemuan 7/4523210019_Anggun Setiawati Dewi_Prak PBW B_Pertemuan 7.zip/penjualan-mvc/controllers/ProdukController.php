<?php
require_once __DIR__ . '/../models/ProdukModel.php';

class ProdukController {
    private $model;

    public function __construct($koneksi) {
        $this->model = new ProdukModel($koneksi);
    }

    public function index() {
        $produk = $this->model->getAllProduk();
        require __DIR__ . '/../views/produk/index.php';
    }

    public function create() {
        require __DIR__ . '/../views/produk/create.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php");
            exit;
        }

        $nama = trim($_POST['nama_produk'] ?? '');
        $hargaInput = $_POST['harga'] ?? '';
        $stokInput = $_POST['stok'] ?? '';

        if ($nama === '' || !is_numeric($hargaInput) || !is_numeric($stokInput)
            || (float)$hargaInput < 0 || (float)$stokInput < 0
            || (float)$stokInput != (int)$stokInput) {
            exit("Input tidak valid. Periksa nama, harga, dan stok.");
        }

        $berhasil = $this->model->tambahProduk(
            $nama, (float)$hargaInput, (int)$stokInput
        );

        if ($berhasil) {
            header("Location: index.php?pesan=tambah");
            exit;
        }
        exit("Gagal menambahkan produk.");
    }

    public function edit() {
        $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
        if (!$id || $id < 1) {
            header("Location: index.php");
            exit;
        }

        $produk = $this->model->getProdukById($id);
        if (!$produk) {
            header("Location: index.php");
            exit;
        }
        require __DIR__ . '/../views/produk/edit.php';
    }

    public function update() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header("Location: index.php");
            exit;
        }

        $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
        $nama = trim($_POST['nama_produk'] ?? '');
        $hargaInput = $_POST['harga'] ?? '';
        $stokInput = $_POST['stok'] ?? '';

        if (!$id || $id < 1 || $nama === '' || !is_numeric($hargaInput)
            || !is_numeric($stokInput) || (float)$hargaInput < 0
            || (float)$stokInput < 0 || (float)$stokInput != (int)$stokInput) {
            exit("Input tidak valid. Periksa kembali data produk.");
        }

        $berhasil = $this->model->updateProduk(
            $id, $nama, (float)$hargaInput, (int)$stokInput
        );

        if ($berhasil) {
            header("Location: index.php?pesan=update");
            exit;
        }
        exit("Gagal memperbarui produk.");
    }
}
?>